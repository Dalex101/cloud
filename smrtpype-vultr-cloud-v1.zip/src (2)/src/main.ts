import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { SafeArea } from 'capacitor-plugin-safe-area';

platformBrowserDynamic()
  .bootstrapModule(AppModule)
  .catch(err => console.log(err));

SafeArea.getSafeAreaInsets().then(data => {
  const { insets } = data;
  document.body.style.setProperty('--ion-safe-area-top', `${insets.top}px`);
  document.body.style.setProperty('--ion-safe-area-right', `${insets.right}px`);
  document.body.style.setProperty('--ion-safe-area-bottom', `${insets.bottom}px`);
  document.body.style.setProperty('--ion-safe-area-left', `${insets.left}px`);
});
