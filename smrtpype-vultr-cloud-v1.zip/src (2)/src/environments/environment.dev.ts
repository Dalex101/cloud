import { Environment } from 'src/app/models/environment';

export const environment: Environment = {
  name: 'dev',
  production: true,
  apiUrl: 'http://192.168.1.176:5000/api/smrtpype', // RasPI
  // apiUrl: 'http://192.168.1.194:5000/api/smrtpype'    // RasPI2
};
