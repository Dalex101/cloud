export interface SystemSettingsMini {
  ssr: number;
  mss: number;
  tsz: number;
  htt: number;
  srr: number;
  tf: 'C' | 'F';
  ssid: string;
  pswd: string;
}
