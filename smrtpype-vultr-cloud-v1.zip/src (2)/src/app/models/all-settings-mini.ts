import { DangerousSettingsMini } from './dangerous-settings-mini';
import { SystemSettingsMini } from './system-settings-mini';

export interface AllSettingsMini {
  s: SystemSettingsMini;
  d: DangerousSettingsMini;
}
