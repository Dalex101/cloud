export interface DangerousSettingsMini {
  th: number;
  sdp: number;
  hth: number;
  htma: number;
  htmto: number;
  htmh: number;
  rdp: number;
  rdt: number;
  rdew: number;
}
