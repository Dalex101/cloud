export interface Environment {
  name: string;
  production: boolean;
  apiUrl: string;
}
