export interface SystemSettings {
  sensor_sample_rate: number;
  mariadb_sample_size: number;
  trend_sample_size: number;
  heat_tape_threshold: number;
  status_refresh_rate: number;
  celsius_fahrenheit: 'C' | 'F';
  wifi_ssid: string;
  wifi_password: string;
}
