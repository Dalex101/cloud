export interface KeyIndicators {
  system_status: string;
  sensor_name: string;
  sensor_value1: number;
  temp_unit: string;
  trend: string;
  heat_tape_state: string;
  rapid_temp_drop_state: string;
  report_date: string;
  system_version: string;
  mod_date_frozen: string;
  heat_tape_manual_state: string;
  heat_tape_manual_alert: number;
  heat_tape_manual_turn_off: number;
  manual_ht_turned_off: string;
}
