export interface KeyIndicatorsMini {
  ss: string;
  sn: string;
  sv: number;
  tu: string;
  tr: string;
  hts: string;
  rds: string;
  rd: string;
  ver: string;
  mdf: string;
  htms: string;
  htma: number;
  htto: number;
  mhto: string;
}
