import { DangerousSettings } from './dangerous-settings';
import { SystemSettings } from './system-settings';

export interface AllSettings {
  systemSettings: SystemSettings;
  dangerousSettings: DangerousSettings;
}
