export interface DangerousSettings {
  trend_hysteresis: number;
  sensor_data_purge_offset: number;
  heat_tape_hysteresis: number;
  heat_tape_manual_alert: number;
  heat_tape_manual_turn_off: number;
  heat_tape_manual_hysteresis: number;
  rapid_drop_period: number;
  rapid_drop_threshold: number;
  rapid_drop_end_wait: number;
}
