import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { Preferences } from '@capacitor/preferences';

@Component({
  selector: 'app-weather',
  templateUrl: './weather.page.html',
  styleUrls: ['./weather.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule],
})
export class WeatherPage {
  zipControl = new FormControl('');
  weather: any = null;
  loading = false;
  error = '';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    Preferences.get({ key: 'weatherZip' }).then(result => {
      if (result.value) {
        this.zipControl.setValue(result.value);
        this.fetchForecast();
      }
    });
  }

  async fetchForecast() {
    this.error = '';
    this.weather = null;
    this.loading = true;
    const zip = this.zipControl.value;
    if (zip) {
      Preferences.set({ key: 'weatherZip', value: zip });
    }
    const apiKey = 'c7239d576ca18561e314ae372089eacc'; // Replace with your key
    this.http
      .get(`https://api.openweathermap.org/data/2.5/forecast?zip=${zip},us&units=imperial&appid=${apiKey}`)
      .subscribe({
        next: (data: any) => {
          // Group forecasts by date
          const grouped: { [date: string]: any[] } = {};
          data.list.forEach((item: any) => {
            const date = item.dt_txt.split(' ')[0];
            if (!grouped[date]) grouped[date] = [];
            grouped[date].push(item);
          });
          // Get forecasts for the next 2–4 days (skip today)
          const dates = Object.keys(grouped).slice(1, 4);
          this.weather = dates.map(date => ({
            date,
            forecasts: grouped[date],
          }));
          this.loading = false;
        },
        error: err => {
          console.error(err);
          this.error = 'Could not fetch forecast. Check ZIP code and try again.';
          this.loading = false;
        },
      });
  }
}
