import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BleClient, BleDevice, ScanResult } from '@capacitor-community/bluetooth-le';
import { IonicModule, isPlatform } from '@ionic/angular';
import { BLUETOOTH_SERVICE_UUID } from 'src/app/constants/bluetooth';
import { ApiService } from 'src/app/services/api.service';
import { ErrorService } from 'src/app/services/error.service';
import { MqttService as MqttEnhancedService, MqttConnectionStatus } from 'src/app/services/mqtt-enhanced.service';

// const HEART_RATE_SERVICE = numberToUUID(0x180d);

@Component({
  selector: 'app-bluetooth',
  templateUrl: 'bluetooth.page.html',
  styleUrls: ['bluetooth.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
})
export class BluetoothPage {
  isScanning: boolean = false;
  scanResults: ScanResult[] = [];
  scanError: string = '';
  connecting: boolean = false;
  disconnecting: boolean = false;

  constructor(
    private errorService: ErrorService,
    private apiService: ApiService,
    private mqttService: MqttEnhancedService
  ) {}

  async ionViewDidEnter() {
    console.log('enter bluetooth page');
  }

  async ionViewWillLeave() {
    this.stopScan();
  }

  get connectedDevice() {
    return this.apiService.connectedDevice;
  }

  async scan(): Promise<void> {
    this.scanError = '';

    if (!isPlatform('hybrid')) {
      this.scanError = 'Bluetooth LE is only available on mobile devices';
      return;
    }

    try {
      this.isScanning = true;
      this.scanResults = [];
      console.log('BleClient', BleClient);
      await BleClient.initialize({ androidNeverForLocation: true });

      await BleClient.requestLEScan(
        {
          services: [BLUETOOTH_SERVICE_UUID],
        },
        result => {
          console.log('received new scan result', result);
          this.scanResults.push(result);
        }
      );

      setTimeout(() => {
        this.stopScan();
      }, 5 * 1000);
    } catch (error: any) {
      console.error(error);
      this.scanError = error.message;
      this.isScanning = false;
    }
  }

  async connect(device: BleDevice): Promise<void> {
    this.connecting = true;
    
    // Disconnect MQTT if connected (BLE and MQTT are mutually exclusive)
    if (this.mqttService.connectionStatus === MqttConnectionStatus.Connected) {
      console.log('BLE: Disconnecting MQTT before BLE connection...');
      this.mqttService.disconnect();
    }
    
    try {
      console.log('Connecting to device:', device);
      await BleClient.connect(device.deviceId, disconnectedDeviceId => {
        console.log('Handle disconnected from device:', disconnectedDeviceId);
        this.apiService.setConnectedDevice(null);
      });
      console.log('Connected to device:', device);
      this.apiService.setConnectedDevice(device);
    } catch (err) {
      this.errorService.displayError('Error connecting to device', err, true);
      this.apiService.setConnectedDevice(null);
    }
    this.connecting = false;

    if (this.connectedDevice) {
      try {
        await this.apiService.loadInitialSettings();
      } catch (err) {
        this.errorService.displayError('Error loading initial settings', err, true);
      }
    }
  }

  async disconnect(): Promise<void> {
    if (!this.connectedDevice) {
      this.apiService.setConnectedDevice(null);
      console.info('No device connected to disconnect from');
      return;
    }

    this.disconnecting = true;
    try {
      console.log('Disconnecting from device:', this.connectedDevice);
      await BleClient.disconnect(this.connectedDevice.deviceId);
      console.log('Disconnected from device:', this.connectedDevice);
      this.apiService.setConnectedDevice(null);
    } catch (err) {
      this.errorService.displayError('Error disconnecting from device', err, true);
    }
    this.disconnecting = false;
  }

  private stopScan() {
    console.log('Stopping scan');
    if (this.isScanning) {
      BleClient.stopLEScan();
      this.isScanning = false;
    }
  }
}
