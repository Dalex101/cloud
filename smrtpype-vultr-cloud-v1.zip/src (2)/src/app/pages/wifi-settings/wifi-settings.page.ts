import { CommonModule } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { ApiService } from '../../services/api.service';
import { MqttService, MqttConnectionStatus } from '../../services/mqtt-enhanced.service';
import { ErrorService } from '../../services/error.service';
import { BLUETOOTH_CHARACTERISTICS, BLUETOOTH_SERVICE_UUID } from '../../constants/bluetooth';
import { BleClient, textToDataView } from '@capacitor-community/bluetooth-le';

@Component({
  selector: 'app-wifi-settings',
  templateUrl: 'wifi-settings.page.html',
  styleUrls: ['wifi-settings.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
})
export class WifiSettingsPage implements OnInit, OnDestroy {
  // Local storage keys
  private readonly STORAGE_KEY_SSID = 'wifi_ssid';
  private readonly STORAGE_KEY_PASSWORD = 'wifi_password';

  // Form fields
  wifiSsid: string = '';
  wifiPassword: string = '';
  showPassword: boolean = false;

  // Status
  isConnecting: boolean = false;
  isSaving: boolean = false;
  connectionStatus: string = 'disconnected';
  statusMessage: string = '';
  errorMessage: string = '';

  // Device ID for MQTT (extracted from BLE device)
  deviceId: string = '1cdbd44064bc'; // Default, should come from BLE device

  private subscriptions: Subscription[] = [];

  constructor(
    private apiService: ApiService,
    private mqttService: MqttService,
    private errorService: ErrorService
  ) {}

  ngOnInit() {
    // Load saved WiFi credentials from local storage
    this.loadSavedCredentials();
    
    // Subscribe to MQTT connection status
    this.subscriptions.push(
      this.mqttService.connectionStatus$.subscribe(status => {
        this.connectionStatus = status;
        if (status === MqttConnectionStatus.Connected) {
          this.statusMessage = 'Connected to WiFi/MQTT!';
          this.isConnecting = false;
        } else if (status === MqttConnectionStatus.Error) {
          this.errorMessage = 'MQTT connection failed';
          this.isConnecting = false;
        }
      })
    );
  }

  /**
   * Load saved WiFi credentials from local storage
   */
  private loadSavedCredentials() {
    const savedSsid = localStorage.getItem(this.STORAGE_KEY_SSID);
    const savedPassword = localStorage.getItem(this.STORAGE_KEY_PASSWORD);
    
    if (savedSsid) {
      this.wifiSsid = savedSsid;
    }
    if (savedPassword) {
      this.wifiPassword = savedPassword;
    }
  }

  /**
   * Save WiFi credentials to local storage
   */
  private saveCredentialsToStorage() {
    localStorage.setItem(this.STORAGE_KEY_SSID, this.wifiSsid);
    localStorage.setItem(this.STORAGE_KEY_PASSWORD, this.wifiPassword);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  get bleConnected(): boolean {
    return this.apiService.connectedDevice !== null;
  }

  get mqttConnected(): boolean {
    return this.connectionStatus === MqttConnectionStatus.Connected;
  }

  get canConnect(): boolean {
    // Password can be empty for open WiFi networks
    return this.wifiSsid.trim().length > 0 && 
           this.bleConnected &&
           !this.isConnecting;
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  /**
   * Save WiFi credentials to ESP32 via BLE, then switch to MQTT mode
   */
  async connectToWifi() {
    if (!this.canConnect) return;

    this.isConnecting = true;
    this.errorMessage = '';
    this.statusMessage = 'Saving WiFi credentials...';

    // Save credentials to local storage for future use
    this.saveCredentialsToStorage();

    try {
      const device = this.apiService.connectedDevice;
      if (!device) {
        throw new Error('No BLE device connected');
      }

      // Step 1: Save WiFi SSID via BLE System Settings characteristic
      this.statusMessage = 'Saving WiFi SSID...';
      const ssidPayload = JSON.stringify({ ws: this.wifiSsid });
      await BleClient.write(
        device.deviceId,
        BLUETOOTH_SERVICE_UUID,
        BLUETOOTH_CHARACTERISTICS.SET_SYSTEM_SETTINGS,
        textToDataView(ssidPayload)
      );
      console.log('WiFi SSID saved');

      // Small delay between writes
      await this.delay(500);

      // Step 2: Save WiFi Password via BLE System Settings characteristic
      this.statusMessage = 'Saving WiFi password...';
      const passwordPayload = JSON.stringify({ wp: this.wifiPassword });
      await BleClient.write(
        device.deviceId,
        BLUETOOTH_SERVICE_UUID,
        BLUETOOTH_CHARACTERISTICS.SET_SYSTEM_SETTINGS,
        textToDataView(passwordPayload)
      );
      console.log('WiFi password saved');

      // Small delay
      await this.delay(500);

      // Step 3: Send switch to MQTT command
      this.statusMessage = 'Switching to WiFi mode...';
      const switchPayload = JSON.stringify({ command: 'switch_mqtt' });
      await BleClient.write(
        device.deviceId,
        BLUETOOTH_SERVICE_UUID,
        BLUETOOTH_CHARACTERISTICS.SET_SYSTEM_SETTINGS,
        textToDataView(switchPayload)
      );
      console.log('Switch to MQTT command sent');

      // Step 4: ESP32 will disconnect BLE and connect to WiFi
      // Wait a moment for the ESP32 to switch modes
      this.statusMessage = 'ESP32 switching to WiFi...';
      await this.delay(3000);

      // Step 5: Connect Ionic to MQTT broker with timeout
      this.statusMessage = 'Connecting to MQTT broker...';
      const MQTT_TIMEOUT_MS = 30000; // 30 second timeout
      
      try {
        await Promise.race([
          this.mqttService.connect(this.deviceId),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('MQTT connection timeout')), MQTT_TIMEOUT_MS)
          )
        ]);
        
        this.statusMessage = 'Connected via WiFi/MQTT!';
        this.isConnecting = false;
      } catch (mqttError: any) {
        console.error('MQTT connection failed:', mqttError);
        // Disconnect any partial connection
        this.mqttService.disconnect();
        
        // Show user-friendly error
        if (mqttError.message?.includes('timeout')) {
          this.errorMessage = 'MQTT connection timed out. The network may be blocking MQTT port 8883. Try a different WiFi network.';
        } else {
          this.errorMessage = `MQTT connection failed: ${mqttError.message || 'Unknown error'}. Check network and try again.`;
        }
        this.isConnecting = false;
        return;
      }

    } catch (error: any) {
      console.error('WiFi connection error:', error);
      this.errorMessage = error.message || 'Failed to connect';
      this.isConnecting = false;
    }
  }

  /**
   * Disconnect from MQTT and switch ESP32 back to BLE mode
   */
  async switchToBle() {
    if (!this.mqttConnected) return;

    this.statusMessage = 'Switching back to BLE mode...';

    try {
      // Send switch_ble command via MQTT
      this.mqttService.requestSwitchToBle();

      // Disconnect MQTT
      await this.delay(1000);
      this.mqttService.disconnect();

      this.statusMessage = 'Switched to BLE mode. Go to Bluetooth page to reconnect.';
      this.connectionStatus = 'disconnected';

    } catch (error: any) {
      console.error('Switch to BLE error:', error);
      this.errorMessage = error.message || 'Failed to switch';
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
