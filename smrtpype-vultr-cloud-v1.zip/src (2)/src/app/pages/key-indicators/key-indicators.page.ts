import { CommonModule } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule, ToastController } from '@ionic/angular';
import { Subscription, interval } from 'rxjs';
import { TOAST_DURATION } from 'src/app/constants/general';
import { KeyIndicators } from 'src/app/models/key-indicators';
import { ApiService } from 'src/app/services/api.service';
import { MqttService as MqttEnhancedService, MqttConnectionStatus } from 'src/app/services/mqtt-enhanced.service';
import { ErrorService } from 'src/app/services/error.service';

@Component({
  selector: 'app-key-indicators',
  templateUrl: './key-indicators.page.html',
  styleUrls: ['./key-indicators.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule],
})
export class KeyIndicatorsPage implements OnInit, OnDestroy {
  heatTape: boolean = false;
  saving: boolean = false;
  errorMessage: string = '';
  keyIndicators: KeyIndicators | undefined;
  connectionMode: 'ble' | 'mqtt' | 'none' = 'none';
  
  private subscriptions: Subscription[] = [];
  private refreshInterval: Subscription | null = null;

  constructor(
    private apiService: ApiService,
    private mqttService: MqttEnhancedService,
    private errorService: ErrorService,
    private toastCtrl: ToastController
  ) {}

  ngOnInit() {
    // Subscribe to MQTT key indicators
    this.subscriptions.push(
      this.mqttService.keyIndicators$.subscribe((ki: KeyIndicators) => {
        console.log('MQTT: Key Indicators received', ki);
        this.keyIndicators = ki;
        this.heatTape = ki.heat_tape_manual_state === 'On';
        this.connectionMode = 'mqtt';
      })
    );

    // Subscribe to MQTT connection status
    this.subscriptions.push(
      this.mqttService.connectionStatus$.subscribe((status) => {
        if (status === MqttConnectionStatus.Connected) {
          this.connectionMode = 'mqtt';
        }
      })
    );

    // Subscribe to BLE connection status
    this.subscriptions.push(
      this.apiService.connectedDevice$.subscribe((device) => {
        if (device && this.mqttService.connectionStatus !== MqttConnectionStatus.Connected) {
          this.connectionMode = 'ble';
        } else if (!device && this.mqttService.connectionStatus !== MqttConnectionStatus.Connected) {
          this.connectionMode = 'none';
        }
      })
    );
  }

  ionViewWillEnter() {
    console.log('Entered Key Indicators Page');
    this.determineConnectionMode();
    this.loadKeyIndicators();
    this.startAutoRefresh();
  }

  ionViewWillLeave() {
    console.log('Leaving Key Indicators Page');
    this.stopAutoRefresh();
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
    this.stopAutoRefresh();
  }

  private determineConnectionMode() {
    if (this.mqttService.connectionStatus === MqttConnectionStatus.Connected) {
      this.connectionMode = 'mqtt';
    } else if (this.apiService.connectedDevice) {
      this.connectionMode = 'ble';
    } else {
      this.connectionMode = 'none';
    }
    console.log('Connection mode:', this.connectionMode);
  }

  private startAutoRefresh() {
    // Auto-refresh every 5 seconds for both BLE and MQTT modes
    // MQTT also gets push updates, but requesting ensures we stay in sync
    this.refreshInterval = interval(5000).subscribe(() => {
      if (this.connectionMode === 'ble' || this.connectionMode === 'mqtt') {
        this.loadKeyIndicators();
      }
    });
  }

  private stopAutoRefresh() {
    if (this.refreshInterval) {
      this.refreshInterval.unsubscribe();
      this.refreshInterval = null;
    }
  }

  async loadKeyIndicators() {
    if (this.connectionMode === 'ble') {
      await this.loadFromBle();
    } else if (this.connectionMode === 'mqtt') {
      // Request KIs from MQTT - they will arrive via subscription
      this.mqttService.requestKeyIndicators();
    }
  }

  private async loadFromBle() {
    try {
      if (!this.apiService.connectedDevice) {
        console.log('No BLE device connected');
        return;
      }

      console.log('Loading Key Indicators via BLE...');
      const ki = await this.apiService.getKeyIndicators();
      console.log('BLE: Key Indicators received', ki);
      
      this.keyIndicators = ki;
      this.heatTape = ki.heat_tape_manual_state === 'On';
      this.errorMessage = '';
      
    } catch (err: any) {
      console.error('BLE read error:', err);
      this.errorMessage = err?.message || 'Failed to read from device';
    }
  }

  async onHeatTapeChange(event: any) {
    const isChecked = event.detail.checked;
    
    if (this.saving) return;

    this.saving = true;
    const previousState = this.heatTape;
    this.heatTape = isChecked;

    try {
      const state = isChecked ? 'On' : 'Off';
      console.log(`Setting manual heat tape to ${state} via ${this.connectionMode}`);

      if (this.connectionMode === 'ble') {
        await this.apiService.saveHeatTapeManualState(state);
      } else if (this.connectionMode === 'mqtt') {
        await this.mqttService.setManualHeatTapeState(state);
      } else {
        throw new Error('No connection available');
      }

      const toast = await this.toastCtrl.create({
        header: 'Success',
        message: `Heat tape set to ${state}`,
        color: 'success',
        duration: TOAST_DURATION,
      });
      await toast.present();

      // Refresh KIs after change
      setTimeout(() => this.loadKeyIndicators(), 1000);

    } catch (err: any) {
      console.error('Heat tape toggle error:', err);
      this.errorService.displayError('Command Failed', err, true);
      this.heatTape = previousState;
    } finally {
      this.saving = false;
    }
  }

  get connectionStatusText(): string {
    switch (this.connectionMode) {
      case 'ble': return 'Connected via Bluetooth';
      case 'mqtt': return 'Connected via WiFi';
      default: return 'Not connected';
    }
  }

  get connectionStatusColor(): string {
    switch (this.connectionMode) {
      case 'ble': return 'primary';
      case 'mqtt': return 'success';
      default: return 'medium';
    }
  }
}