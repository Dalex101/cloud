import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule, ToastController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { TOAST_DURATION } from 'src/app/constants/general';
import { KeyIndicators } from 'src/app/models/key-indicators';
import { ApiService } from 'src/app/services/api.service';
import { ErrorService } from 'src/app/services/error.service';

@Component({
  selector: 'app-key-indicators',
  templateUrl: './key-indicators.page.html',
  styleUrls: ['./key-indicators.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule],
})
export class KeyIndicatorsPage implements OnInit {
  heatTape: boolean = false;
  saving: boolean = false;
  refreshRate: number = 5;
  errorMessage: string = '';
  refreshInterval: any;
  keyIndicators: KeyIndicators | undefined;

  constructor(
    private apiService: ApiService,
    private errorService: ErrorService,
    private toastCtrl: ToastController
  ) {}

  ngOnInit() {}

  ionViewWillEnter() {
    console.log('enter key indicators page');
    this.loadKeyIndicators();
    this.startAutoRefresh();
  }

  // ngOnDestroy() is not fired in ionic pages; it keeps them alive
  ionViewWillLeave() {
    console.log('leave key indicators page');
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }

  async loadKeyIndicators() {
    this.errorMessage = '';
    try {
      this.keyIndicators = await this.apiService.getKeyIndicators();
      this.heatTape = this.keyIndicators.heat_tape_manual_state === 'On';

      // if (systemStatus && systemStatus.value !== 'GREEN') {
      //   if (modDateFrozen && modDateFrozen.value === 'True') {
      //     this.errorMessage = 'Sensor has stopped running';
      //   } else {
      //     this.errorMessage = '401: Cannot access system.';
      //   }
      // } else {
      //   this.message = '';
      // }

      // if (response
    } catch (err) {
      console.error('Error loading key indicators:', err);
      this.errorMessage = this.errorService.getErrorMessage(err);
    }
  }

  async onHeatTapeChange(event: any) {
    this.heatTape = event.detail.checked;

    // wait to avoid flashing the UI on connection error
    await new Promise(resolve => setTimeout(resolve, 200));

    this.saving = true;
    try {
      console.log('Saving heat tape:', this.heatTape);
      const response = await this.apiService.saveHeatTapeManualState(this.heatTape ? 'On' : 'Off');
      this.toastCtrl
        .create({
          header: 'Heat Tape Updated Successfully',
          message: `Heat tape state set to ${this.heatTape}`,
          color: 'success',
          duration: TOAST_DURATION,
        })
        .then(toast => toast.present());
      console.log('Save heat tape response:', response);
    } catch (err) {
      console.error('Error saving heat tape:', err);
      this.errorService.displayError('Error saving heat tape', err, true);

      // reverse the UI change
      this.heatTape = !this.heatTape;
    }
    this.saving = false;
  }

  private startAutoRefresh() {
    this.refreshInterval = setInterval(() => {
      this.loadKeyIndicators();
    }, this.refreshRate * 1000);
  }
}
