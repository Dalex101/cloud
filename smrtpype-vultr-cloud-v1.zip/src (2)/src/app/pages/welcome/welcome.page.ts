import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Preferences } from '@capacitor/preferences';
import { IonicModule, ModalController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, RouterModule, FormsModule, ReactiveFormsModule],
})
export class WelcomePage {
  constructor(private modalCtrl: ModalController, private navCtrl: NavController) {}

  dismiss() {
    Preferences.set({ key: 'welcomed', value: 'true' });
    this.modalCtrl.dismiss();
    this.navCtrl.navigateRoot('/bluetooth');
  }
}
