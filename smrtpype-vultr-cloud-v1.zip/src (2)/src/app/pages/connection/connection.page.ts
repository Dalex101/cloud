import { CommonModule } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BleClient, BleDevice, ScanResult, textToDataView } from '@capacitor-community/bluetooth-le';
import { IonicModule, isPlatform } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { BLUETOOTH_SERVICE_UUID, BLUETOOTH_CHARACTERISTICS } from 'src/app/constants/bluetooth';
import { ApiService } from 'src/app/services/api.service';
import { ErrorService } from 'src/app/services/error.service';
import { MqttService, MqttConnectionStatus } from 'src/app/services/mqtt-enhanced.service';

@Component({
  selector: 'app-connection',
  templateUrl: 'connection.page.html',
  styleUrls: ['connection.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
})
export class ConnectionPage implements OnInit, OnDestroy {
  // Local storage keys
  private readonly STORAGE_KEY_SSID = 'wifi_ssid';
  private readonly STORAGE_KEY_PASSWORD = 'wifi_password';

  // BLE State
  isScanning: boolean = false;
  scanResults: ScanResult[] = [];
  scanError: string = '';
  connecting: boolean = false;
  disconnecting: boolean = false;

  // WiFi State
  /*
  wifiSsid: string = '';
  wifiPassword: string = '';
  showPassword: boolean = false;
  isConnectingWifi: boolean = false;
  */
  // HIDE WIFI
  wifiSsid: string = '';
  wifiPassword: string = '';
  showPassword: boolean = false;
  isConnectingWifi: boolean = false;
  // HIDE WIFI END

  // Status
  statusMessage: string = '';
  errorMessage: string = '';

  // Device ID for MQTT (extracted from BLE device)
  deviceId: string = '1cdbd44064bc';

  private subscriptions: Subscription[] = [];

  constructor(
    private apiService: ApiService,
    private mqttService: MqttService,
    private errorService: ErrorService
  ) {}

  ngOnInit() {
    // Load saved WiFi credentials
    this.loadSavedCredentials();

    // Subscribe to MQTT connection status
    this.subscriptions.push(
      this.mqttService.connectionStatus$.subscribe(status => {
        if (status === MqttConnectionStatus.Connected) {
          this.statusMessage = 'Connected to WiFi/MQTT!';
          this.isConnectingWifi = false;
        } else if (status === MqttConnectionStatus.Error) {
          this.errorMessage = 'MQTT connection failed';
          this.isConnectingWifi = false;
        }
      })
    );
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  ionViewDidEnter() {
    console.log('enter connection page');
  }

  ionViewWillLeave() {
    this.stopScan();
  }

  // ==================== GETTERS ====================

  get connectedDevice(): BleDevice | null {
    return this.apiService.connectedDevice;
  }

  get bleConnected(): boolean {
    return this.apiService.connectedDevice !== null;
  }

  get mqttConnected(): boolean {
    // return this.mqttService.connectionStatus === MqttConnectionStatus.Connected;
    return false;
  }

  get connectionMode(): 'ble' | 'wifi' | 'none' {
    if (this.mqttConnected) return 'wifi';
    if (this.bleConnected) return 'ble';
    return 'none';
  }

  get canScanBle(): boolean {
    return !this.mqttConnected && !this.isScanning && !this.connecting;
  }

/*
  get canConnectWifi(): boolean {
    return this.wifiSsid.trim().length > 0 && 
           this.bleConnected &&
           !this.mqttConnected &&
           !this.isConnectingWifi;
  }
  */

  get canConnectWifi(): boolean {
    return false;
  }

  // ==================== LOCAL STORAGE ====================

  private loadSavedCredentials() {
    const savedSsid = localStorage.getItem(this.STORAGE_KEY_SSID);
    const savedPassword = localStorage.getItem(this.STORAGE_KEY_PASSWORD);
    if (savedSsid) this.wifiSsid = savedSsid;
    if (savedPassword) this.wifiPassword = savedPassword;
  }

  private saveCredentialsToStorage() {
    localStorage.setItem(this.STORAGE_KEY_SSID, this.wifiSsid);
    localStorage.setItem(this.STORAGE_KEY_PASSWORD, this.wifiPassword);
  }

  // ==================== BLE METHODS ====================

  async scan(): Promise<void> {
    this.scanError = '';
    this.errorMessage = '';

    if (!isPlatform('hybrid')) {
      this.scanError = 'Bluetooth LE is only available on mobile devices';
      return;
    }

    if (this.mqttConnected) {
      this.scanError = 'Disconnect from WiFi first to scan for BLE devices';
      return;
    }

    try {
      this.isScanning = true;
      this.scanResults = [];
      await BleClient.initialize({ androidNeverForLocation: true });

      await BleClient.requestLEScan(
        { services: [BLUETOOTH_SERVICE_UUID] },
        result => {
          console.log('received new scan result', result);
          this.scanResults.push(result);
        }
      );

      setTimeout(() => this.stopScan(), 5 * 1000);
    } catch (error: any) {
      console.error(error);
      this.scanError = error.message;
      this.isScanning = false;
    }
  }

  async connectBle(device: BleDevice): Promise<void> {
    this.connecting = true;
    this.errorMessage = '';

    // Disconnect MQTT if connected
    if (this.mqttConnected) {
      console.log('BLE: Disconnecting MQTT before BLE connection...');
      this.mqttService.disconnect();
    }

    try {
      console.log('Connecting to device:', device);
      await BleClient.connect(device.deviceId, disconnectedDeviceId => {
        console.log('Handle disconnected from device:', disconnectedDeviceId);
        this.apiService.setConnectedDevice(null);
      });
      console.log('Connected to device:', device);
      this.apiService.setConnectedDevice(device);
      this.statusMessage = `Connected to ${device.name || 'device'} via Bluetooth`;
    } catch (err) {
      this.errorService.displayError('Error connecting to device', err, true);
      this.apiService.setConnectedDevice(null);
    }
    this.connecting = false;

    if (this.connectedDevice) {
      try {
        await this.apiService.loadInitialSettings();
      } catch (err) {
        this.errorService.displayError('Error loading initial settings', err, true);
      }
    }
  }

  async disconnectBle(): Promise<void> {
    if (!this.connectedDevice) {
      this.apiService.setConnectedDevice(null);
      return;
    }

    this.disconnecting = true;
    try {
      console.log('Disconnecting from device:', this.connectedDevice);
      await BleClient.disconnect(this.connectedDevice.deviceId);
      console.log('Disconnected from device:', this.connectedDevice);
      this.apiService.setConnectedDevice(null);
      this.statusMessage = 'Disconnected from Bluetooth';
    } catch (err) {
      this.errorService.displayError('Error disconnecting from device', err, true);
    }
    this.disconnecting = false;
  }

  private stopScan() {
    console.log('Stopping scan');
    if (this.isScanning) {
      BleClient.stopLEScan();
      this.isScanning = false;
    }
  }

  // ==================== WIFI METHODS ====================

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  async connectToWifi() {
    if (!this.canConnectWifi) return;

    this.isConnectingWifi = true;
    this.errorMessage = '';
    this.statusMessage = 'Saving WiFi credentials...';

    // Save credentials to local storage
    this.saveCredentialsToStorage();

    try {
      const device = this.apiService.connectedDevice;
      if (!device) {
        throw new Error('No BLE device connected');
      }

      // Step 1: Save WiFi SSID via BLE
      this.statusMessage = 'Saving WiFi SSID...';
      const ssidPayload = JSON.stringify({ ws: this.wifiSsid });
      await BleClient.write(
        device.deviceId,
        BLUETOOTH_SERVICE_UUID,
        BLUETOOTH_CHARACTERISTICS.SET_SYSTEM_SETTINGS,
        textToDataView(ssidPayload)
      );
      console.log('WiFi SSID saved');
      await this.delay(500);

      // Step 2: Save WiFi Password via BLE
      this.statusMessage = 'Saving WiFi password...';
      const passwordPayload = JSON.stringify({ wp: this.wifiPassword });
      await BleClient.write(
        device.deviceId,
        BLUETOOTH_SERVICE_UUID,
        BLUETOOTH_CHARACTERISTICS.SET_SYSTEM_SETTINGS,
        textToDataView(passwordPayload)
      );
      console.log('WiFi password saved');
      await this.delay(500);

      // Step 3: Send switch to MQTT command
      this.statusMessage = 'Switching to WiFi mode...';
      const switchPayload = JSON.stringify({ command: 'switch_mqtt' });
      await BleClient.write(
        device.deviceId,
        BLUETOOTH_SERVICE_UUID,
        BLUETOOTH_CHARACTERISTICS.SET_SYSTEM_SETTINGS,
        textToDataView(switchPayload)
      );
      console.log('Switch to MQTT command sent');

      // Step 4: Wait for ESP32 to switch modes
      this.statusMessage = 'ESP32 switching to WiFi...';
      await this.delay(3000);

      // Step 5: Connect Ionic to MQTT broker with timeout
      this.statusMessage = 'Connecting to MQTT broker...';
      const MQTT_TIMEOUT_MS = 30000;

      try {
        await Promise.race([
          this.mqttService.connect(this.deviceId),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error('MQTT connection timeout')), MQTT_TIMEOUT_MS)
          )
        ]);

        this.statusMessage = 'Connected via WiFi/MQTT!';
        this.isConnectingWifi = false;
      } catch (mqttError: any) {
        console.error('MQTT connection failed:', mqttError);
        this.mqttService.disconnect();

        if (mqttError.message?.includes('timeout')) {
          this.errorMessage = 'MQTT connection timed out. The network may be blocking MQTT port 8883.';
        } else {
          this.errorMessage = `MQTT connection failed: ${mqttError.message || 'Unknown error'}`;
        }
        this.isConnectingWifi = false;
        return;
      }

    } catch (error: any) {
      console.error('WiFi connection error:', error);
      this.errorMessage = error.message || 'Failed to connect';
      this.isConnectingWifi = false;
    }
  }

  async switchToBle() {
    if (!this.mqttConnected) return;

    this.statusMessage = 'Switching back to BLE mode...';

    try {
      // Send switch_ble command via MQTT
      this.mqttService.requestSwitchToBle();
      await this.delay(1000);
      this.mqttService.disconnect();

      this.statusMessage = 'Switched to BLE mode. Scan to reconnect.';
    } catch (error: any) {
      console.error('Switch to BLE error:', error);
      this.errorMessage = error.message || 'Failed to switch';
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
