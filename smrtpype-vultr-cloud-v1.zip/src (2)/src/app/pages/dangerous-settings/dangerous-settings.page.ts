import { CommonModule } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AlertController, IonicModule, ToastController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { TOAST_DURATION } from 'src/app/constants/general';
import { ApiService } from 'src/app/services/api.service';
import { MqttService as MqttEnhancedService, MqttConnectionStatus } from 'src/app/services/mqtt-enhanced.service';
import { ErrorService } from 'src/app/services/error.service';

@Component({
  selector: 'app-dangerous-settings',
  templateUrl: './dangerous-settings.page.html',
  styleUrls: ['./dangerous-settings.page.scss'],
  standalone: true,
  imports: [IonicModule, FormsModule, CommonModule, FormsModule, ReactiveFormsModule],
})
export class DangerousSettingsPage implements OnDestroy {
  formGroup: FormGroup = new FormGroup({
    trend_hysteresis: new FormControl(null, [Validators.required]),
    sensor_data_purge_offset: new FormControl(null, [Validators.required]),
    heat_tape_hysteresis: new FormControl(null, [Validators.required]),
    heat_tape_manual_alert: new FormControl(null, [Validators.required]),
    heat_tape_manual_turn_off: new FormControl(null, [Validators.required]),
    heat_tape_manual_hysteresis: new FormControl(null, [Validators.required]),
    rapid_drop_period: new FormControl(null, [Validators.required]),
    rapid_drop_threshold: new FormControl(null, [Validators.required]),
    rapid_drop_end_wait: new FormControl(null, [Validators.required]),
  });
  saving: boolean = false;
  connectionMode: 'ble' | 'mqtt' | 'none' = 'none';

  private subscriptions: Subscription[] = [];

  constructor(
    private apiService: ApiService,
    private mqttService: MqttEnhancedService,
    private errorService: ErrorService,
    private toastCtrl: ToastController,
    private alertCtrl: AlertController
  ) {
    // Subscribe to MQTT all settings
    this.subscriptions.push(
      this.mqttService.allSettings$.subscribe((settings) => {
        console.log('MQTT: All Settings received', settings);
        if (settings.dangerousSettings) {
          this.formGroup.patchValue(settings.dangerousSettings);
        }
      })
    );
  }

  async ionViewWillEnter() {
    console.log('enter dangerous settings page');
    this.determineConnectionMode();
    this.load();
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  private determineConnectionMode() {
    if (this.mqttService.connectionStatus === MqttConnectionStatus.Connected) {
      this.connectionMode = 'mqtt';
    } else if (this.apiService.connectedDevice) {
      this.connectionMode = 'ble';
    } else {
      this.connectionMode = 'none';
    }
    console.log('Connection mode:', this.connectionMode);
  }

  async save() {
    this.saving = true;
    try {
      console.log('Saving dangerous settings:', this.formGroup.getRawValue());
      
      if (this.connectionMode === 'ble') {
        await this.apiService.saveDangerousSettings(this.formGroup.getRawValue());
      } else if (this.connectionMode === 'mqtt') {
        await this.mqttService.saveDangerousSettings(this.formGroup.getRawValue());
      } else {
        throw new Error('No connection available');
      }

      this.toastCtrl
        .create({
          header: 'Dangerous Settings Saved Successfully',
          message: `Your changes have been sent to the device.`,
          color: 'success',
          duration: TOAST_DURATION,
        })
        .then(toast => toast.present());
    } catch (err) {
      console.error('Error:', err);
      this.errorService.displayError('Error saving dangerous settings', err, true);
    }
    this.saving = false;
  }

  reset() {
    this.alertCtrl
      .create({
        header: 'Reset to Factory Settings',
        message: 'Are you sure you want to reset to factory settings? This action cannot be undone.',
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
          },
          {
            text: 'Reset',
            handler: () => {
              this.saving = true;
              
              const resetPromise = this.connectionMode === 'mqtt'
                ? this.mqttService.factoryReset()
                : this.apiService.resetToFactorySettings();

              resetPromise
                .then(() => {
                  this.load();
                  this.toastCtrl
                    .create({
                      header: 'Reset Successful',
                      message: `Device has been reset to factory settings.`,
                      color: 'success',
                      duration: TOAST_DURATION,
                    })
                    .then(toast => toast.present());
                })
                .catch(err => {
                  this.errorService.displayError('Error resetting to factory settings', err, true);
                })
                .finally(() => {
                  this.saving = false;
                });
            },
          },
        ],
      })
      .then(alert => alert.present());
  }

  private async load() {
    try {
      if (this.connectionMode === 'ble') {
        const settings = await this.apiService.getDangerousSettings();
        this.formGroup.patchValue(settings);
      } else if (this.connectionMode === 'mqtt') {
        // Request settings - they will arrive via subscription
        this.mqttService.requestAllSettings();
      }
    } catch (err) {
      console.error('Error loading dangerous settings:', err);
      this.errorService.displayError('Error loading dangerous settings', err, true);
    }
  }

  get connectionStatusText(): string {
    switch (this.connectionMode) {
      case 'ble': return 'Bluetooth';
      case 'mqtt': return 'WiFi';
      default: return 'Not connected';
    }
  }
}
