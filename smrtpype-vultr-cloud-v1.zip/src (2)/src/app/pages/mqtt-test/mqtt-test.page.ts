/**
 * MQTT Test Page
 * Simple page to test MQTT connection to ESP32
 * Add this to your Ionic app for testing
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { MqttService, MqttConnectionStatus } from '../../services/mqtt-enhanced.service';
import { KeyIndicators } from '../../models/key-indicators';

@Component({
  selector: 'app-mqtt-test',
  templateUrl: './mqtt-test.page.html',
  styleUrls: ['./mqtt-test.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
})
export class MqttTestPage {
  // Your ESP32 device ID from the test output
  deviceId: string = '1cdbd44064bc';
  
  connectionStatus: string = 'Disconnected';
  lastKI: KeyIndicators | null = null;
  lastAck: any = null;
  messages: string[] = [];
  
  // Manual heat tape state
  manualHtState: string = 'Off';

  constructor(private mqttService: MqttService) {
    // Subscribe to connection status
    this.mqttService.connectionStatus$.subscribe((status: MqttConnectionStatus) => {
      this.connectionStatus = status;
      this.log(`Connection status: ${status}`);
    });

    // Subscribe to Key Indicators
    this.mqttService.keyIndicators$.subscribe((ki: KeyIndicators) => {
      this.lastKI = ki;
      this.log(`Received KI: temp=${ki.sensor_value1}${ki.temp_unit}, status=${ki.system_status}`);
    });

    // Subscribe to ACKs
    this.mqttService.ack$.subscribe((ack: any) => {
      this.lastAck = ack;
      this.log(`Received ACK: ${ack.ack} - ${ack.status}`);
    });

    // Subscribe to raw messages for debugging
    this.mqttService.rawMessage$.subscribe((msg: {topic: string, payload: any}) => {
      this.log(`Raw: [${msg.topic}] ${JSON.stringify(msg.payload).substring(0, 50)}...`);
    });
  }

  async connect() {
    try {
      this.log(`Connecting to device ${this.deviceId}...`);
      await this.mqttService.connect(this.deviceId);
      this.log('Connected!');
    } catch (err: any) {
      this.log(`Connection error: ${err.message}`);
    }
  }

  disconnect() {
    this.mqttService.disconnect();
    this.log('Disconnected');
  }

  requestKI() {
    this.log('Requesting Key Indicators...');
    this.mqttService.requestKeyIndicators();
  }

  requestSettings() {
    this.log('Requesting All Settings...');
    this.mqttService.requestAllSettings();
  }

  async toggleManualHt() {
    const newState = this.manualHtState === 'Off' ? 'On' : 'Off';
    this.log(`Setting manual heat tape to: ${newState}`);
    try {
      await this.mqttService.setManualHeatTapeState(newState as 'On' | 'Off');
      this.manualHtState = newState;
      this.log(`Manual heat tape set to ${newState}`);
    } catch (err: any) {
      this.log(`Error: ${err.message}`);
    }
  }

  async factoryReset() {
    if (confirm('Are you sure you want to factory reset the device?')) {
      this.log('Sending factory reset...');
      try {
        await this.mqttService.factoryReset();
        this.log('Factory reset complete!');
      } catch (err: any) {
        this.log(`Error: ${err.message}`);
      }
    }
  }

  requestSwitchToBle() {
    this.log('Requesting ESP32 switch to BLE mode...');
    this.mqttService.requestSwitchToBle();
  }

  clearLog() {
    this.messages = [];
  }

  private log(message: string) {
    const timestamp = new Date().toLocaleTimeString();
    this.messages.unshift(`[${timestamp}] ${message}`);
    console.log(message);
  }
}
