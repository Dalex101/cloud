import { CommonModule } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { IonicModule, ToastController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { TOAST_DURATION } from 'src/app/constants/general';
import { ApiService } from 'src/app/services/api.service';
import { MqttService as MqttEnhancedService, MqttConnectionStatus } from 'src/app/services/mqtt-enhanced.service';
import { ErrorService } from 'src/app/services/error.service';

@Component({
  selector: 'app-system-settings',
  templateUrl: './system-settings.page.html',
  styleUrls: ['./system-settings.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule],
})
export class SystemSettingsPage implements OnDestroy {
  formGroup: FormGroup = new FormGroup({
    sensor_sample_rate: new FormControl(null, [Validators.required, Validators.min(0)]),
    mariadb_sample_size: new FormControl(null, [Validators.required]),
    trend_sample_size: new FormControl(null, [Validators.required]),
    heat_tape_threshold: new FormControl(null, [Validators.required]),
    status_refresh_rate: new FormControl(null, [Validators.required]),
    celsius_fahrenheit: new FormControl('', [Validators.required]),
    wifi_ssid: new FormControl('', [Validators.required, Validators.maxLength(32)]),
    wifi_password: new FormControl('', [Validators.maxLength(63)]),  // Not required - allows open WiFi networks
  });
  saving: boolean = false;
  connectionMode: 'ble' | 'mqtt' | 'none' = 'none';

  private subscriptions: Subscription[] = [];

  constructor(
    private apiService: ApiService,
    private mqttService: MqttEnhancedService,
    private errorService: ErrorService,
    private toastCtrl: ToastController
  ) {
    // Subscribe to MQTT all settings
    this.subscriptions.push(
      this.mqttService.allSettings$.subscribe((settings) => {
        console.log('MQTT: All Settings received', settings);
        if (settings.systemSettings) {
          this.formGroup.patchValue(settings.systemSettings);
        }
      })
    );
  }

  ionViewWillEnter() {
    console.log('enter system settings page');
    this.determineConnectionMode();
    this.load();
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  private determineConnectionMode() {
    if (this.mqttService.connectionStatus === MqttConnectionStatus.Connected) {
      this.connectionMode = 'mqtt';
    } else if (this.apiService.connectedDevice) {
      this.connectionMode = 'ble';
    } else {
      this.connectionMode = 'none';
    }
    console.log('Connection mode:', this.connectionMode);
  }

  async save() {
    this.saving = true;
    try {
      console.log('Saving system settings:', this.formGroup.getRawValue());
      
      if (this.connectionMode === 'ble') {
        await this.apiService.saveSystemSettings(this.formGroup.getRawValue());
      } else if (this.connectionMode === 'mqtt') {
        await this.mqttService.saveSystemSettings(this.formGroup.getRawValue());
      } else {
        throw new Error('No connection available');
      }

      this.toastCtrl
        .create({
          header: 'System Settings Saved Successfully',
          message: `Your changes have been sent to the device.`,
          color: 'success',
          duration: TOAST_DURATION,
        })
        .then(toast => toast.present());
    } catch (err) {
      console.error('Error:', err);
      this.errorService.displayError('Error saving system settings', err, true);
    }
    this.saving = false;
  }

  private async load() {
    try {
      if (this.connectionMode === 'ble') {
        const settings = await this.apiService.getSystemSettings();
        this.formGroup.patchValue(settings);
      } else if (this.connectionMode === 'mqtt') {
        // Request settings - they will arrive via subscription
        this.mqttService.requestAllSettings();
      }
    } catch (err) {
      console.error('Error loading system settings:', err);
      this.errorService.displayError('Error loading system settings', err, true);
    }
  }

  get connectionStatusText(): string {
    switch (this.connectionMode) {
      case 'ble': return 'Bluetooth';
      case 'mqtt': return 'WiFi';
      default: return 'Not connected';
    }
  }
}
