import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'key-indicators',
    pathMatch: 'full',
  },
  {
    path: 'key-indicators',
    loadComponent: () => import('./pages/key-indicators/key-indicators.page').then(m => m.KeyIndicatorsPage),
  },
  {
    path: 'connection',
    loadComponent: () => import('./pages/connection/connection.page').then(m => m.ConnectionPage),
  },
  {
    path: 'bluetooth',
    redirectTo: 'connection',
    pathMatch: 'full',
  },
  {
    path: 'wifi-settings',
    redirectTo: 'connection',
    pathMatch: 'full',
  },
  {
    path: 'dangerous-settings',
    loadComponent: () =>
      import('./pages/dangerous-settings/dangerous-settings.page').then(m => m.DangerousSettingsPage),
  },
  {
    path: 'system-settings',
    loadComponent: () =>
      import('./pages/system-settings/system-settings.page').then(m => m.SystemSettingsPage),
  },
  {
    path: 'weather',
    loadComponent: () => import('./pages/weather/weather.page').then(m => m.WeatherPage),
  },
  {
    path: 'mqtt-test',
    loadComponent: () => import('./pages/mqtt-test/mqtt-test.page').then(m => m.MqttTestPage)
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
