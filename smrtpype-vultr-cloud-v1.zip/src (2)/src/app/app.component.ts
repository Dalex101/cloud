import { Component } from '@angular/core';
import { Preferences } from '@capacitor/preferences';
import { SplashScreen } from '@capacitor/splash-screen';
import { ModalController } from '@ionic/angular';
import { environment } from 'src/environments/environment';
import { WelcomePage } from './pages/welcome/welcome.page';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent {
  constructor(private modalCtrl: ModalController) {
    this.initializeApp();
  }

  get envName() {
    return environment.name;
  }

  initializeApp() {
    /* To make sure we provide the fastest app loading experience
       for our users, hide the splash screen automatically
       when the app is ready to be used:

        https://capacitor.ionicframework.com/docs/apis/splash-screen#hiding-the-splash-screen
    */
    SplashScreen.hide();

    this.tryOpenWelcomeModal();
  }

  private tryOpenWelcomeModal() {
    Preferences.get({ key: 'welcomed' }).then(result => {
      if (!result.value) {
        this.modalCtrl
          .create({
            component: WelcomePage,
          })
          .then(modal => {
            modal.present();
          });
      }
    });
  }
}
