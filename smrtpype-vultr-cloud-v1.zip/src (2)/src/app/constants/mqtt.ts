/**
 * MQTT Configuration Constants
 * Defines broker settings and topic structure for ESP32-S3 communication
 * Updated: 2026-01-20
 */

// ============================================================================
// HIVEMQ CLOUD SETTINGS
// ============================================================================

export const MQTT_CONFIG = {
  // HiveMQ Cloud Broker (WebSocket URL for browser/Ionic)
  BROKER_URL: 'wss://cce37b43acbf455b8f608188de9d78b5.s1.eu.hivemq.cloud:8884/mqtt',
  
  // Authentication
  USERNAME: 'justtesting',
  PASSWORD: 'Hi19821984!',
  
  // Connection options
  KEEPALIVE: 60,
  RECONNECT_PERIOD: 5000, // ms
  CONNECT_TIMEOUT: 30000, // ms
};

// ============================================================================
// MQTT TOPIC STRUCTURE
// ============================================================================
// All topics are prefixed with device_id for multi-device support
// Format: esp32/{device_id}/{topic}

export const MQTT_TOPICS = {
  // Topics the ESP32 PUBLISHES to (Ionic subscribes)
  KEY_INDICATORS: 'ki',
  ALL_SETTINGS: 'settings/all',
  ACK: 'ack',
  
  // Topics the ESP32 SUBSCRIBES to (Ionic publishes)
  CMD_SYSTEM_SETTINGS: 'cmd/settings/system',
  CMD_DANGER_SETTINGS: 'cmd/settings/danger',
  CMD_FACTORY_RESET: 'cmd/factory_reset',
  CMD_MANUAL_HT: 'cmd/manual_ht',
  CMD_REQUEST_KI: 'cmd/request_ki',
  CMD_REQUEST_SETTINGS: 'cmd/request_settings',
  CMD_SWITCH_TO_BLE: 'cmd/switch_ble',
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Build full MQTT topic with device ID prefix
 * @param deviceId - The unique device identifier (12-char hex)
 * @param topicSuffix - The topic suffix (e.g., 'ki', 'cmd/manual_ht')
 * @returns Full topic string (e.g., 'esp32/a4cf12fe2301/ki')
 */
export function buildTopic(deviceId: string, topicSuffix: string): string {
  return `esp32/${deviceId}/${topicSuffix}`;
}

/**
 * Get all topics this app should subscribe to for a device
 * @param deviceId - The unique device identifier
 * @returns Object with named topics
 */
export function getSubscribeTopics(deviceId: string) {
  return {
    keyIndicators: buildTopic(deviceId, MQTT_TOPICS.KEY_INDICATORS),
    allSettings: buildTopic(deviceId, MQTT_TOPICS.ALL_SETTINGS),
    ack: buildTopic(deviceId, MQTT_TOPICS.ACK),
  };
}

/**
 * Get all topics this app publishes to for a device
 * @param deviceId - The unique device identifier
 * @returns Object with named topics
 */
export function getPublishTopics(deviceId: string) {
  return {
    systemSettings: buildTopic(deviceId, MQTT_TOPICS.CMD_SYSTEM_SETTINGS),
    dangerSettings: buildTopic(deviceId, MQTT_TOPICS.CMD_DANGER_SETTINGS),
    factoryReset: buildTopic(deviceId, MQTT_TOPICS.CMD_FACTORY_RESET),
    manualHt: buildTopic(deviceId, MQTT_TOPICS.CMD_MANUAL_HT),
    requestKi: buildTopic(deviceId, MQTT_TOPICS.CMD_REQUEST_KI),
    requestSettings: buildTopic(deviceId, MQTT_TOPICS.CMD_REQUEST_SETTINGS),
    switchToBle: buildTopic(deviceId, MQTT_TOPICS.CMD_SWITCH_TO_BLE),
  };
}
