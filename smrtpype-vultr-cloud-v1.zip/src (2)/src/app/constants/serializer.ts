import { KeyIndicators } from '../models/key-indicators';
import { KeyIndicatorsMini } from '../models/key-indicators-mini';
import { SystemSettings } from '../models/system-settings';
import { SystemSettingsMini } from '../models/system-settings-mini';
import { DangerousSettings } from '../models/dangerous-settings';
import { DangerousSettingsMini } from '../models/dangerous-settings-mini';
import { AllSettings } from '../models/all-settings';
import { AllSettingsMini } from '../models/all-settings-mini';

export function serializeKeyIndicators(data: KeyIndicators): KeyIndicatorsMini {
  return {
    ss: data.system_status,
    sn: data.sensor_name,
    sv: data.sensor_value1,
    tu: data.temp_unit,
    tr: data.trend,
    hts: data.heat_tape_state,
    rds: data.rapid_temp_drop_state,
    rd: data.report_date,
    ver: data.system_version,
    mdf: data.mod_date_frozen,
    htms: data.heat_tape_manual_state,
    htma: data.heat_tape_manual_alert,
    htto: data.heat_tape_manual_turn_off,
    mhto: data.manual_ht_turned_off,
  };
}

export function deserializeKeyIndicators(data: KeyIndicatorsMini): KeyIndicators {
  return {
    system_status: data.ss,
    sensor_name: data.sn,
    sensor_value1: data.sv,
    temp_unit: data.tu,
    trend: data.tr,
    heat_tape_state: data.hts,
    rapid_temp_drop_state: data.rds,
    report_date: data.rd,
    system_version: data.ver,
    mod_date_frozen: data.mdf,
    heat_tape_manual_state: data.htms,
    heat_tape_manual_alert: data.htma,
    heat_tape_manual_turn_off: data.htto,
    manual_ht_turned_off: data.mhto,
  };
}

export function serializeSystemSettings(data: SystemSettings): SystemSettingsMini {
  return {
    ssr: data.sensor_sample_rate,
    mss: data.mariadb_sample_size,
    tsz: data.trend_sample_size,
    htt: data.heat_tape_threshold,
    srr: data.status_refresh_rate,
    tf: data.celsius_fahrenheit,
    ssid: data.wifi_ssid,
    pswd: data.wifi_password,
  };
}

export function deserializeSystemSettings(data: SystemSettingsMini): SystemSettings {
  return {
    sensor_sample_rate: data.ssr,
    mariadb_sample_size: data.mss,
    trend_sample_size: data.tsz,
    heat_tape_threshold: data.htt,
    status_refresh_rate: data.srr,
    celsius_fahrenheit: data.tf,
    wifi_ssid: data.ssid,
    wifi_password: data.pswd,
  };
}

export function serializeDangerousSettings(data: DangerousSettings): DangerousSettingsMini {
  return {
    th: data.trend_hysteresis,
    sdp: data.sensor_data_purge_offset,
    hth: data.heat_tape_hysteresis,
    htma: data.heat_tape_manual_alert,
    htmto: data.heat_tape_manual_turn_off,
    htmh: data.heat_tape_manual_hysteresis,
    rdp: data.rapid_drop_period,
    rdt: data.rapid_drop_threshold,
    rdew: data.rapid_drop_end_wait,
  };
}

export function deserializeDangerousSettings(data: DangerousSettingsMini): DangerousSettings {
  return {
    trend_hysteresis: data.th,
    sensor_data_purge_offset: data.sdp,
    heat_tape_hysteresis: data.hth,
    heat_tape_manual_alert: data.htma,
    heat_tape_manual_turn_off: data.htmto,
    heat_tape_manual_hysteresis: data.htmh,
    rapid_drop_period: data.rdp,
    rapid_drop_threshold: data.rdt,
    rapid_drop_end_wait: data.rdew,
  };
}

export function serializeAllSettings(data: AllSettings): AllSettingsMini {
  return {
    s: serializeSystemSettings(data.systemSettings),
    d: serializeDangerousSettings(data.dangerousSettings),
  };
}

export function deserializeAllSettings(data: AllSettingsMini): AllSettings {
  return {
    systemSettings: deserializeSystemSettings(data.s),
    dangerousSettings: deserializeDangerousSettings(data.d),
  };
}
