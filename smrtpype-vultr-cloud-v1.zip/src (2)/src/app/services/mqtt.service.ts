import { Injectable } from '@angular/core';
import mqtt from 'mqtt'; 
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MqttService {
  private client: any;
  public incomingMessages$ = new Subject<string>();
  public connectionStatus = new Subject<string>();

  constructor() { }

  connect() {
    // UPDATED: Using Vultr IP with WebSocket protocol on Port 9001
    const BROKER_URL = 'ws://66.42.119.171:9001'; 
    
    const options: any = {
      username: 'smrt_user',      // EXACT USERNAME
      password: 'abcd1234',       // EXACT PASSWORD
      clientId: 'mobile_app_' + Math.random().toString(16).substring(2, 8),
      // Path is usually required for browser-based MQTT clients
      path: '/mqtt' 
    };

    console.log("Attempting to connect to Vultr Cloud VPS...");
    
    try {
      this.client = mqtt.connect(BROKER_URL, options);

      this.client.on('connect', () => {
        console.log("SUCCESS: Connected to SMRTpype Vultr Cloud!");
        this.connectionStatus.next('Connected');
        
        // SUBSCRIBE TO DEVICE TOPICS:
        // We use '+' as a wildcard so you see data from ANY Device ID
        this.client.subscribe('esp32/+/ki');  // Key Indicators (Compressed)
        this.client.subscribe('esp32/+/ack'); // Acknowledgments
      });

      this.client.on('message', (topic: string, payload: any) => {
        const msg = payload.toString();
        // This is where your compressed data (sv, tr, etc.) arrives
        console.log(`Cloud Message [${topic}]: ${msg}`);
        this.incomingMessages$.next(msg);
      });

      this.client.on('error', (err: any) => {
        console.error("MQTT Connection Error:", err);
        this.connectionStatus.next('Error');
      });

      this.client.on('close', () => {
        console.warn("MQTT Connection closed");
        this.connectionStatus.next('Disconnected');
      });

    } catch (e) {
      console.error("Failed to initialize MQTT client:", e);
    }
  }

  public sendEsp32Command(deviceId: string, topicSuffix: string, command: any) {
    if (this.client && this.client.connected) {
      // Build the topic dynamically: esp32/DEVICE_ID/cmd/TOPIC_SUFFIX
      const fullTopic = `esp32/${deviceId}/cmd/${topicSuffix}`;
      const payload = JSON.stringify(command);
      
      console.log(`Publishing to ${fullTopic}:`, payload);
      this.client.publish(fullTopic, payload);
    } else {
      console.error("Cannot send: MQTT not connected");
    }
  }
}