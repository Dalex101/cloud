import { HttpClient } from '@angular/common/http';
import { ErrorHandler, Injectable } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { TOAST_DURATION } from '../constants/general';

@Injectable({
  providedIn: 'root',
})
export class ErrorService implements ErrorHandler {
  constructor(private toastCtrl: ToastController, private httpClient: HttpClient) {}

  async displayError(prefix: string, error: any, sendToApi: boolean): Promise<void> {
    const fullErrorMessage = `${prefix}: ${this.getErrorMessage(error)}`;

    const toast = await this.toastCtrl.create({
      message: fullErrorMessage,
      duration: TOAST_DURATION,
      color: 'danger',
    });
    await toast.present();

    // if (sendToApi) {
    // Uncomment the following line to send the error to the API
    // await this.sendLogToApi({ message: fullErrorMessage });
    // }
  }

  public handleError(error: any): void {
    console.error('Error occured:', error);
  }

  // public sendLogToApi(apiLog: ApiLog): Promise<void> {
  //   return firstValueFrom(this.httpClient.post<void>(this.baseUrl, apiLog));
  // }

  public getErrorMessage(error: any): string {
    return error.error?.message || error.message || error;
  }
}
