/**
 * Enhanced MQTT Service for ESP32-S3 Communication
 * Handles Key Indicators, Settings, and Commands via HiveMQ Cloud
 * Updated: 2026-01-20
 */

import { Injectable } from '@angular/core';
import mqtt, { MqttClient } from 'mqtt';
import { BehaviorSubject, Subject } from 'rxjs';
import {
  MQTT_CONFIG,
  MQTT_TOPICS,
  buildTopic,
  getSubscribeTopics,
  getPublishTopics,
} from '../constants/mqtt';
import {
  deserializeKeyIndicators,
  deserializeAllSettings,
  serializeSystemSettings,
  serializeDangerousSettings,
} from '../constants/serializer';
import { KeyIndicators } from '../models/key-indicators';
import { KeyIndicatorsMini } from '../models/key-indicators-mini';
import { AllSettings } from '../models/all-settings';
import { AllSettingsMini } from '../models/all-settings-mini';
import { SystemSettings } from '../models/system-settings';
import { DangerousSettings } from '../models/dangerous-settings';

// Connection status enum
export enum MqttConnectionStatus {
  Disconnected = 'disconnected',
  Connecting = 'connecting',
  Connected = 'connected',
  Error = 'error',
}

// ACK message structure
export interface MqttAck {
  ack: string;
  status: string;
  timestamp?: number;
  error?: string;
  updated?: string[];
}

@Injectable({
  providedIn: 'root',
})
export class MqttService {
  private client: MqttClient | null = null;
  private _deviceId: string | null = null;
  private pubTopics: ReturnType<typeof getPublishTopics> | null = null;
  private subTopics: ReturnType<typeof getSubscribeTopics> | null = null;

  // Observable streams
  private _connectionStatus$ = new BehaviorSubject<MqttConnectionStatus>(
    MqttConnectionStatus.Disconnected
  );
  private _keyIndicators$ = new Subject<KeyIndicators>();
  private _allSettings$ = new Subject<AllSettings>();
  private _ack$ = new Subject<MqttAck>();
  private _rawMessage$ = new Subject<{ topic: string; payload: any }>();

  constructor() {}

  // ============================================================================
  // PUBLIC OBSERVABLES
  // ============================================================================

  get connectionStatus$() {
    return this._connectionStatus$.asObservable();
  }

  get connectionStatus() {
    return this._connectionStatus$.getValue();
  }

  get keyIndicators$() {
    return this._keyIndicators$.asObservable();
  }

  get allSettings$() {
    return this._allSettings$.asObservable();
  }

  get ack$() {
    return this._ack$.asObservable();
  }

  get rawMessage$() {
    return this._rawMessage$.asObservable();
  }

  get isConnected(): boolean {
    return this._connectionStatus$.getValue() === MqttConnectionStatus.Connected;
  }

  get deviceId(): string | null {
    return this._deviceId;
  }

  // ============================================================================
  // CONNECTION MANAGEMENT
  // ============================================================================

  /**
   * Connect to MQTT broker for a specific device
   * @param deviceId - The unique device identifier (12-char hex from ESP32)
   */
  connect(deviceId: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.client && this.isConnected) {
        console.log('MQTT: Already connected');
        resolve();
        return;
      }

      this._deviceId = deviceId;
      this.pubTopics = getPublishTopics(deviceId);
      this.subTopics = getSubscribeTopics(deviceId);

      this._connectionStatus$.next(MqttConnectionStatus.Connecting);
      console.log(`MQTT: Connecting to ${MQTT_CONFIG.BROKER_URL} for device ${deviceId}...`);

      const options: mqtt.IClientOptions = {
        username: MQTT_CONFIG.USERNAME,
        password: MQTT_CONFIG.PASSWORD,
        clientId: `ionic_${deviceId}_${Math.random().toString(16).substring(2, 8)}`,
        keepalive: MQTT_CONFIG.KEEPALIVE,
        reconnectPeriod: MQTT_CONFIG.RECONNECT_PERIOD,
        connectTimeout: MQTT_CONFIG.CONNECT_TIMEOUT,
      };

      try {
        this.client = mqtt.connect(MQTT_CONFIG.BROKER_URL, options);

        this.client.on('connect', () => {
          console.log('MQTT: Connected successfully!');
          this._connectionStatus$.next(MqttConnectionStatus.Connected);
          this.subscribeToDeviceTopics();
          resolve();
        });

        this.client.on('message', (topic: string, payload: Buffer) => {
          this.handleMessage(topic, payload);
        });

        this.client.on('error', (err: Error) => {
          console.error('MQTT: Connection error:', err);
          this._connectionStatus$.next(MqttConnectionStatus.Error);
          reject(err);
        });

        this.client.on('close', () => {
          console.log('MQTT: Connection closed');
          this._connectionStatus$.next(MqttConnectionStatus.Disconnected);
        });

        this.client.on('reconnect', () => {
          console.log('MQTT: Reconnecting...');
          this._connectionStatus$.next(MqttConnectionStatus.Connecting);
        });

        this.client.on('offline', () => {
          console.log('MQTT: Client offline');
          this._connectionStatus$.next(MqttConnectionStatus.Disconnected);
        });
      } catch (e) {
        console.error('MQTT: Failed to initialize client:', e);
        this._connectionStatus$.next(MqttConnectionStatus.Error);
        reject(e);
      }
    });
  }

  /**
   * Disconnect from MQTT broker
   */
  disconnect(): void {
    if (this.client) {
      console.log('MQTT: Disconnecting...');
      this.client.end();
      this.client = null;
      this._deviceId = null;
      this.pubTopics = null;
      this.subTopics = null;
      this._connectionStatus$.next(MqttConnectionStatus.Disconnected);
    }
  }

  /**
   * Subscribe to all device topics
   */
  private subscribeToDeviceTopics(): void {
    if (!this.client || !this.subTopics) return;

    const topics = Object.values(this.subTopics);
    topics.forEach((topic) => {
      this.client!.subscribe(topic, (err) => {
        if (err) {
          console.error(`MQTT: Subscribe error for ${topic}:`, err);
        } else {
          console.log(`MQTT: Subscribed to ${topic}`);
        }
      });
    });
  }

  // ============================================================================
  // MESSAGE HANDLING
  // ============================================================================

  /**
   * Handle incoming MQTT messages
   */
  private handleMessage(topic: string, payload: Buffer): void {
    try {
      const payloadStr = payload.toString();
      console.log(`MQTT RX [${topic}]: ${payloadStr.substring(0, 100)}...`);

      const data = JSON.parse(payloadStr);

      // Emit raw message for debugging
      this._rawMessage$.next({ topic, payload: data });

      // Route based on topic suffix
      if (!this._deviceId) return;

      const topicSuffix = topic.replace(`esp32/${this._deviceId}/`, '');

      switch (topicSuffix) {
        case MQTT_TOPICS.KEY_INDICATORS:
          this.handleKeyIndicators(data as KeyIndicatorsMini);
          break;

        case MQTT_TOPICS.ALL_SETTINGS:
          this.handleAllSettings(data as AllSettingsMini);
          break;

        case MQTT_TOPICS.ACK:
          this.handleAck(data as MqttAck);
          break;

        default:
          console.log(`MQTT: Unknown topic suffix: ${topicSuffix}`);
      }
    } catch (e) {
      console.error('MQTT: Error handling message:', e);
    }
  }

  private handleKeyIndicators(data: KeyIndicatorsMini): void {
    const ki = deserializeKeyIndicators(data);
    console.log('MQTT: Key Indicators received:', ki);
    this._keyIndicators$.next(ki);
  }

  private handleAllSettings(data: AllSettingsMini): void {
    const settings = deserializeAllSettings(data);
    console.log('MQTT: All Settings received:', settings);
    this._allSettings$.next(settings);
  }

  private handleAck(data: MqttAck): void {
    console.log('MQTT: ACK received:', data);
    this._ack$.next(data);
  }

  // ============================================================================
  // COMMAND METHODS (Publish to ESP32)
  // ============================================================================

  /**
   * Request Key Indicators from ESP32
   */
  requestKeyIndicators(): void {
    this.publish(this.pubTopics?.requestKi, { request: true });
  }

  /**
   * Request all settings from ESP32
   */
  requestAllSettings(): void {
    this.publish(this.pubTopics?.requestSettings, { request: true });
  }

  /**
   * Send system settings update to ESP32
   * @param settings - System settings object
   */
  saveSystemSettings(settings: SystemSettings): Promise<void> {
    return new Promise((resolve, reject) => {
      const serialized = serializeSystemSettings(settings);
      console.log('MQTT: Sending system settings:', serialized);

      // Wait for ACK
      const subscription = this._ack$.subscribe((ack) => {
        if (ack.ack === 'system_settings') {
          subscription.unsubscribe();
          if (ack.status === 'success') {
            resolve();
          } else {
            reject(new Error(ack.error || 'Settings update failed'));
          }
        }
      });

      // Send with timeout
      this.publish(this.pubTopics?.systemSettings, serialized);

      // Timeout after 10 seconds
      setTimeout(() => {
        subscription.unsubscribe();
        reject(new Error('Settings update timeout'));
      }, 10000);
    });
  }

  /**
   * Send dangerous settings update to ESP32
   * @param settings - Dangerous settings object
   */
  saveDangerousSettings(settings: DangerousSettings): Promise<void> {
    return new Promise((resolve, reject) => {
      const serialized = serializeDangerousSettings(settings);
      console.log('MQTT: Sending dangerous settings:', serialized);

      const subscription = this._ack$.subscribe((ack) => {
        if (ack.ack === 'danger_settings') {
          subscription.unsubscribe();
          if (ack.status === 'success') {
            resolve();
          } else {
            reject(new Error(ack.error || 'Settings update failed'));
          }
        }
      });

      this.publish(this.pubTopics?.dangerSettings, serialized);

      setTimeout(() => {
        subscription.unsubscribe();
        reject(new Error('Settings update timeout'));
      }, 10000);
    });
  }

  /**
   * Set manual heat tape state
   * @param state - 'On' or 'Off'
   */
  setManualHeatTapeState(state: 'On' | 'Off'): Promise<void> {
    return new Promise((resolve, reject) => {
      console.log('MQTT: Setting manual heat tape:', state);

      const subscription = this._ack$.subscribe((ack) => {
        if (ack.ack === 'manual_ht') {
          subscription.unsubscribe();
          if (ack.status === 'success') {
            resolve();
          } else {
            reject(new Error(ack.error || 'Manual heat tape update failed'));
          }
        }
      });

      this.publish(this.pubTopics?.manualHt, { state });

      setTimeout(() => {
        subscription.unsubscribe();
        reject(new Error('Manual heat tape update timeout'));
      }, 10000);
    });
  }

  /**
   * Trigger factory reset on ESP32
   */
  factoryReset(): Promise<void> {
    return new Promise((resolve, reject) => {
      console.log('MQTT: Sending factory reset command');

      const subscription = this._ack$.subscribe((ack) => {
        if (ack.ack === 'factory_reset') {
          subscription.unsubscribe();
          if (ack.status === 'success') {
            resolve();
          } else {
            reject(new Error(ack.error || 'Factory reset failed'));
          }
        }
      });

      this.publish(this.pubTopics?.factoryReset, { reset: true });

      setTimeout(() => {
        subscription.unsubscribe();
        reject(new Error('Factory reset timeout'));
      }, 15000); // Longer timeout for factory reset
    });
  }

  /**
   * Request ESP32 to switch back to BLE mode
   */
  requestSwitchToBle(): void {
    console.log('MQTT: Requesting switch to BLE mode');
    this.publish(this.pubTopics?.switchToBle, { switch: true });
  }

  // ============================================================================
  // UTILITY METHODS
  // ============================================================================

  /**
   * Publish message to topic
   */
  private publish(topic: string | undefined, payload: any): void {
    if (!this.client || !topic) {
      console.error('MQTT: Cannot publish - not connected or invalid topic');
      return;
    }

    const payloadStr = JSON.stringify(payload);
    console.log(`MQTT TX [${topic}]: ${payloadStr}`);

    this.client.publish(topic, payloadStr, { qos: 1 }, (err) => {
      if (err) {
        console.error('MQTT: Publish error:', err);
      }
    });
  }
}
