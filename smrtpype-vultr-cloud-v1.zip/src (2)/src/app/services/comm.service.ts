/**
 * Unified Communication Service
 * Abstracts BLE and MQTT communication, allowing seamless switching between modes.
 * Pages use this service instead of directly calling ApiService (BLE) or MqttService.
 * Updated: 2026-01-20
 */

import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject, merge, Subscription } from 'rxjs';
import { filter, take } from 'rxjs/operators';
import { Preferences } from '@capacitor/preferences';

import { ApiService } from './api.service';
import { MqttService, MqttConnectionStatus } from './mqtt-enhanced.service';

import { KeyIndicators } from '../models/key-indicators';
import { AllSettings } from '../models/all-settings';
import { SystemSettings } from '../models/system-settings';
import { DangerousSettings } from '../models/dangerous-settings';

// Communication mode
export enum CommMode {
  None = 'none',
  BLE = 'ble',
  MQTT = 'mqtt',
}

// Connection status (unified across both modes)
export enum ConnectionStatus {
  Disconnected = 'disconnected',
  Connecting = 'connecting',
  Connected = 'connected',
  Error = 'error',
}

// Paired device info (stored in Preferences)
export interface PairedDevice {
  device_id: string;
  nickname: string;
  ble_device_id?: string; // BLE device UUID
  mqtt_topic_prefix: string;
  paired_date: string;
}

@Injectable({
  providedIn: 'root',
})
export class CommService {
  private _mode$ = new BehaviorSubject<CommMode>(CommMode.None);
  private _status$ = new BehaviorSubject<ConnectionStatus>(ConnectionStatus.Disconnected);
  private _keyIndicators$ = new Subject<KeyIndicators>();
  private _allSettings$ = new Subject<AllSettings>();
  private _pairedDevice$ = new BehaviorSubject<PairedDevice | null>(null);

  private mqttSubscription: Subscription | null = null;

  constructor(
    private apiService: ApiService,
    private mqttService: MqttService
  ) {
    // Listen to MQTT connection status changes
    this.mqttService.connectionStatus$.subscribe((status) => {
      if (this._mode$.getValue() === CommMode.MQTT) {
        this._status$.next(this.mapMqttStatus(status));
      }
    });

    // Listen to MQTT key indicators
    this.mqttService.keyIndicators$.subscribe((ki) => {
      if (this._mode$.getValue() === CommMode.MQTT) {
        this._keyIndicators$.next(ki);
      }
    });

    // Listen to MQTT settings
    this.mqttService.allSettings$.subscribe((settings) => {
      if (this._mode$.getValue() === CommMode.MQTT) {
        this._allSettings$.next(settings);
      }
    });

    // Listen to BLE connection status
    this.apiService.connectedDevice$.subscribe((device) => {
      if (this._mode$.getValue() === CommMode.BLE) {
        this._status$.next(device ? ConnectionStatus.Connected : ConnectionStatus.Disconnected);
      }
    });

    // Load paired device from storage
    this.loadPairedDevice();
  }

  // ============================================================================
  // PUBLIC OBSERVABLES
  // ============================================================================

  get mode$(): Observable<CommMode> {
    return this._mode$.asObservable();
  }

  get mode(): CommMode {
    return this._mode$.getValue();
  }

  get status$(): Observable<ConnectionStatus> {
    return this._status$.asObservable();
  }

  get status(): ConnectionStatus {
    return this._status$.getValue();
  }

  get isConnected(): boolean {
    return this._status$.getValue() === ConnectionStatus.Connected;
  }

  get keyIndicators$(): Observable<KeyIndicators> {
    return this._keyIndicators$.asObservable();
  }

  get allSettings$(): Observable<AllSettings> {
    return this._allSettings$.asObservable();
  }

  get pairedDevice$(): Observable<PairedDevice | null> {
    return this._pairedDevice$.asObservable();
  }

  get pairedDevice(): PairedDevice | null {
    return this._pairedDevice$.getValue();
  }

  // ============================================================================
  // CONNECTION MANAGEMENT
  // ============================================================================

  /**
   * Switch to MQTT mode and connect
   * @param deviceId - The ESP32 device ID (12-char hex)
   */
  async connectMqtt(deviceId?: string): Promise<void> {
    const id = deviceId || this._pairedDevice$.getValue()?.device_id;
    if (!id) {
      throw new Error('No device ID provided or paired');
    }

    console.log(`COMM: Switching to MQTT mode for device ${id}`);

    // Disconnect BLE if connected
    if (this._mode$.getValue() === CommMode.BLE) {
      await this.disconnectBle();
    }

    this._mode$.next(CommMode.MQTT);
    this._status$.next(ConnectionStatus.Connecting);

    try {
      await this.mqttService.connect(id);
      console.log('COMM: MQTT connected');
    } catch (e) {
      console.error('COMM: MQTT connection failed:', e);
      this._status$.next(ConnectionStatus.Error);
      throw e;
    }
  }

  /**
   * Switch to BLE mode
   * Note: BLE connection is handled by BluetoothPage via ApiService
   */
  switchToBle(): void {
    console.log('COMM: Switching to BLE mode');

    // Disconnect MQTT if connected
    if (this._mode$.getValue() === CommMode.MQTT) {
      this.mqttService.disconnect();
    }

    this._mode$.next(CommMode.BLE);

    // Update status based on current BLE connection
    const bleConnected = this.apiService.connectedDevice !== null;
    this._status$.next(bleConnected ? ConnectionStatus.Connected : ConnectionStatus.Disconnected);
  }

  /**
   * Disconnect current connection
   */
  disconnect(): void {
    const mode = this._mode$.getValue();

    if (mode === CommMode.MQTT) {
      this.mqttService.disconnect();
    } else if (mode === CommMode.BLE) {
      this.disconnectBle();
    }

    this._status$.next(ConnectionStatus.Disconnected);
  }

  private async disconnectBle(): Promise<void> {
    // BLE disconnect is handled by BluetoothPage
    // This just updates our internal state
    console.log('COMM: BLE disconnect requested');
  }

  // ============================================================================
  // DATA METHODS (MODE-AGNOSTIC)
  // ============================================================================

  /**
   * Get Key Indicators
   * Works with both BLE and MQTT modes
   */
  async getKeyIndicators(): Promise<KeyIndicators> {
    const mode = this._mode$.getValue();

    if (mode === CommMode.BLE) {
      return this.apiService.getKeyIndicators();
    } else if (mode === CommMode.MQTT) {
      // Request KI and wait for response
      return new Promise((resolve, reject) => {
        const subscription = this._keyIndicators$.pipe(take(1)).subscribe({
          next: (ki) => resolve(ki),
          error: (err) => reject(err),
        });

        this.mqttService.requestKeyIndicators();

        // Timeout
        setTimeout(() => {
          subscription.unsubscribe();
          reject(new Error('Key Indicators request timeout'));
        }, 10000);
      });
    } else {
      throw new Error('Not connected');
    }
  }

  /**
   * Get all settings
   */
  async getAllSettings(): Promise<AllSettings> {
    const mode = this._mode$.getValue();

    if (mode === CommMode.BLE) {
      // BLE loads settings via loadInitialSettings
      const systemSettings = await this.apiService.getSystemSettings();
      const dangerousSettings = await this.apiService.getDangerousSettings();
      return { systemSettings, dangerousSettings };
    } else if (mode === CommMode.MQTT) {
      return new Promise((resolve, reject) => {
        const subscription = this._allSettings$.pipe(take(1)).subscribe({
          next: (settings) => resolve(settings),
          error: (err) => reject(err),
        });

        this.mqttService.requestAllSettings();

        setTimeout(() => {
          subscription.unsubscribe();
          reject(new Error('All Settings request timeout'));
        }, 10000);
      });
    } else {
      throw new Error('Not connected');
    }
  }

  /**
   * Save system settings
   */
  async saveSystemSettings(settings: SystemSettings): Promise<void> {
    const mode = this._mode$.getValue();

    if (mode === CommMode.BLE) {
      return this.apiService.saveSystemSettings(settings);
    } else if (mode === CommMode.MQTT) {
      return this.mqttService.saveSystemSettings(settings);
    } else {
      throw new Error('Not connected');
    }
  }

  /**
   * Save dangerous settings
   */
  async saveDangerousSettings(settings: DangerousSettings): Promise<void> {
    const mode = this._mode$.getValue();

    if (mode === CommMode.BLE) {
      return this.apiService.saveDangerousSettings(settings);
    } else if (mode === CommMode.MQTT) {
      return this.mqttService.saveDangerousSettings(settings);
    } else {
      throw new Error('Not connected');
    }
  }

  /**
   * Set manual heat tape state
   */
  async setManualHeatTapeState(state: 'On' | 'Off'): Promise<void> {
    const mode = this._mode$.getValue();

    if (mode === CommMode.BLE) {
      return this.apiService.saveHeatTapeManualState(state);
    } else if (mode === CommMode.MQTT) {
      return this.mqttService.setManualHeatTapeState(state);
    } else {
      throw new Error('Not connected');
    }
  }

  /**
   * Factory reset
   */
  async factoryReset(): Promise<void> {
    const mode = this._mode$.getValue();

    if (mode === CommMode.BLE) {
      return this.apiService.resetToFactorySettings();
    } else if (mode === CommMode.MQTT) {
      return this.mqttService.factoryReset();
    } else {
      throw new Error('Not connected');
    }
  }

  /**
   * Request ESP32 to switch back to BLE mode (MQTT only)
   */
  requestEspSwitchToBle(): void {
    if (this._mode$.getValue() === CommMode.MQTT) {
      this.mqttService.requestSwitchToBle();
    }
  }

  // ============================================================================
  // DEVICE PAIRING
  // ============================================================================

  /**
   * Save paired device info
   * Called after successful BLE pairing when device_id is obtained
   */
  async savePairedDevice(device: PairedDevice): Promise<void> {
    await Preferences.set({
      key: 'paired_device',
      value: JSON.stringify(device),
    });

    this._pairedDevice$.next(device);
    console.log('COMM: Paired device saved:', device);
  }

  /**
   * Load paired device from storage
   */
  private async loadPairedDevice(): Promise<void> {
    try {
      const result = await Preferences.get({ key: 'paired_device' });
      if (result.value) {
        const device = JSON.parse(result.value) as PairedDevice;
        this._pairedDevice$.next(device);
        console.log('COMM: Loaded paired device:', device);
      }
    } catch (e) {
      console.error('COMM: Error loading paired device:', e);
    }
  }

  /**
   * Clear paired device
   */
  async clearPairedDevice(): Promise<void> {
    await Preferences.remove({ key: 'paired_device' });
    this._pairedDevice$.next(null);
    console.log('COMM: Paired device cleared');
  }

  // ============================================================================
  // UTILITIES
  // ============================================================================

  private mapMqttStatus(status: MqttConnectionStatus): ConnectionStatus {
    switch (status) {
      case MqttConnectionStatus.Connected:
        return ConnectionStatus.Connected;
      case MqttConnectionStatus.Connecting:
        return ConnectionStatus.Connecting;
      case MqttConnectionStatus.Error:
        return ConnectionStatus.Error;
      default:
        return ConnectionStatus.Disconnected;
    }
  }
}
