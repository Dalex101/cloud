import { Injectable } from '@angular/core';
import { BleClient, BleDevice, dataViewToText, textToDataView } from '@capacitor-community/bluetooth-le';
import { Preferences } from '@capacitor/preferences';
import { BehaviorSubject } from 'rxjs';
import { BLUETOOTH_CHARACTERISTICS, BLUETOOTH_SERVICE_UUID } from '../constants/bluetooth';
import {
  deserializeAllSettings,
  deserializeDangerousSettings,
  deserializeKeyIndicators,
  deserializeSystemSettings,
  serializeDangerousSettings,
  serializeSystemSettings,
} from '../constants/serializer';
import { AllSettings } from '../models/all-settings';
import { DangerousSettings } from '../models/dangerous-settings';
import { KeyIndicators } from '../models/key-indicators';
import { SystemSettings } from '../models/system-settings';
import { AllSettingsMini } from '../models/all-settings-mini';
import { KeyIndicatorsMini } from '../models/key-indicators-mini';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private _connectedDevice$: BehaviorSubject<BleDevice | null> = new BehaviorSubject<BleDevice | null>(null);

  constructor() {}

  get connectedDevice$() {
    return this._connectedDevice$.asObservable();
  }

  get connectedDevice() {
    return this._connectedDevice$.getValue();
  }

  setConnectedDevice(device: BleDevice | null) {
    this._connectedDevice$.next(device);
  }

  getSystemSettings(): Promise<SystemSettings> {
    return Preferences.get({ key: 'system_settings' }).then(result => {
      console.log('getSystemSettings result', result.value);
      if (result.value) {
        return JSON.parse(result.value) as SystemSettings;
      }
      return {} as SystemSettings;
    });
  }

  saveSystemSettings(settings: SystemSettings): Promise<void> {
    Preferences.set({
      key: 'system_settings',
      value: JSON.stringify(settings),
    });

    return this.writeMessage<void>(
      BLUETOOTH_CHARACTERISTICS.SET_SYSTEM_SETTINGS,
      serializeSystemSettings(settings)
    );
  }

  getDangerousSettings(): Promise<DangerousSettings> {
    return Preferences.get({ key: 'dangerous_settings' }).then(result => {
      if (result.value) {
        console.log('getDangerousSettings result', result.value);
        return JSON.parse(result.value) as DangerousSettings;
      }
      return {} as DangerousSettings;
    });
  }

  saveDangerousSettings(settings: DangerousSettings): Promise<void> {
    Preferences.set({
      key: 'dangerous_settings',
      value: JSON.stringify(settings),
    });

    return this.writeMessage<void>(
      BLUETOOTH_CHARACTERISTICS.SET_DANGEROUS_SETTINGS,
      serializeDangerousSettings(settings)
    );
  }

  saveHeatTapeManualState(val: string): Promise<void> {
    return this.writeMessage<void>(BLUETOOTH_CHARACTERISTICS.SET_HEAT_TAPE_MANUAL_STATE, val);
  }

  async resetToFactorySettings(): Promise<void> {
    // Send factory reset command
    await this.writeMessage<AllSettings>(BLUETOOTH_CHARACTERISTICS.FACTORY_RESET, true);

    // Wait for ESP32 to complete factory reset and update BLE characteristics
    // ESP32 needs time to: (1) reset NVS values, (2) update BLE characteristics
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Now read the updated settings from ESP32
    const allSettingsMini = await this.readMessage<AllSettingsMini>(
      BLUETOOTH_CHARACTERISTICS.GET_ALL_SETTINGS
    );
    console.log('resetToFactorySettings result', allSettingsMini);

    const allSettings = deserializeAllSettings(allSettingsMini);

    await Preferences.set({
      key: 'system_settings',
      value: JSON.stringify(allSettings.systemSettings),
    });

    await Preferences.set({
      key: 'dangerous_settings',
      value: JSON.stringify(allSettings.dangerousSettings),
    });
  }

  async loadInitialSettings(): Promise<void> {
    const allSettingsMini = await this.readMessage<AllSettingsMini>(
      BLUETOOTH_CHARACTERISTICS.GET_ALL_SETTINGS
    );
    console.log('loadInitialSettings result', allSettingsMini);

    const allSettings = deserializeAllSettings(allSettingsMini);

    await Preferences.set({
      key: 'system_settings',
      value: JSON.stringify(allSettings.systemSettings),
    });

    await Preferences.set({
      key: 'dangerous_settings',
      value: JSON.stringify(allSettings.dangerousSettings),
    });
  }

  async getKeyIndicators(): Promise<KeyIndicators> {
    const keyIndicatorsMini = await this.readMessage<KeyIndicatorsMini>(
      BLUETOOTH_CHARACTERISTICS.GET_KEY_INDICATORS
    );
    console.log('getKeyIndicators result', keyIndicatorsMini);
    return deserializeKeyIndicators(keyIndicatorsMini);
  }

  private writeMessage<T>(characteristic: string, message: any): Promise<T> {
    return new Promise((resolve, reject) => {
      if (!this.connectedDevice) {
        reject(new Error('No connected device'));
        return;
      }

      // write the data
      BleClient.write(
        this.connectedDevice.deviceId,
        BLUETOOTH_SERVICE_UUID,
        characteristic,
        textToDataView(JSON.stringify(message)),
        {
          timeout: 5000,
        }
      )
        .then(value => {
          console.log('Wrote message successfully', message);
          console.log('Write result', value);
          resolve(message as T);
        })
        .catch(err => {
          console.error('Error writing message:', err, err?.message);
          reject(err);
        });
    });
  }

  private readMessage<T>(characteristic: string): Promise<T> {
    return new Promise((resolve, reject) => {
      if (!this.connectedDevice) {
        reject(new Error('No connected device'));
        return;
      }

      BleClient.read(this.connectedDevice.deviceId, BLUETOOTH_SERVICE_UUID, characteristic, {
        timeout: 5000,
      })
        .then(result => {
          const resultString = dataViewToText(result);
          console.log('Read message successfully', resultString);
          resolve(JSON.parse(resultString) as T);
        })
        .catch(err => {
          console.error('Error reading message:', err, err?.message);
          reject(err);
        });
    });
  }

  private writeFieldsOneByOne<T>(characteristic: string, message: any): Promise<T> {
    return new Promise(async (resolve, reject) => {
      if (!this.connectedDevice) {
        reject(new Error('No connected device'));
        return;
      }

      try {
        for (const key of Object.keys(message)) {
          // write x=y
          const payload = `${key}=${message[key]}`;
          console.log('Writing field message', payload);
          await BleClient.write(
            this.connectedDevice.deviceId,
            BLUETOOTH_SERVICE_UUID,
            characteristic,
            textToDataView(JSON.stringify(payload)),
            {
              timeout: 5000,
            }
          );
        }
        console.log('Wrote all field messages successfully', message);
        resolve(message as T);
      } catch (err) {
        console.error('Error writing field messages:', err);
        reject(err);
      }
    });
  }
}
